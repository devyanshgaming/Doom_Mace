@echo off
setlocal
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven is not installed. Install Maven 3.9+ and Java 21, then run this file again.
  pause
  exit /b 1
)
mvn clean package
if errorlevel 1 exit /b 1
echo.
echo Built: target\doommace-1.0.0.jar
pause
