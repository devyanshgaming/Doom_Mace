package com.doommace;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.NamespacedKey;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class DoomMacePlugin extends JavaPlugin implements Listener {
    private NamespacedKey doomKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private boolean applyingAbilityDamage = false;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        doomKey = new NamespacedKey(this, "doom_mace");
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (isDoomMace(online.getInventory().getItemInMainHand())) {
                    Location hand = online.getEyeLocation().add(online.getLocation().getDirection().multiply(0.35));
                    online.getWorld().spawnParticle(Particle.DUST, hand, 2, 0.12, 0.12, 0.12,
                            new Particle.DustOptions(org.bukkit.Color.fromRGB(105, 0, 12), 0.8f));
                }
            }
        }, 20L, 20L);
        getLogger().info("DoomMace enabled.");
    }

    @Override
    public void onDisable() {
        cooldowns.clear();
    }

    private boolean isDoomMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return false;
        Byte marker = item.getItemMeta().getPersistentDataContainer().get(doomKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte) 1;
    }

    private ItemStack createDoomMace() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_RED + "Doom Mace");
        meta.setLore(java.util.List.of(
                ChatColor.GRAY + "A legendary weapon forged in doom.",
                ChatColor.DARK_RED + "Right-click: Doom Smash",
                ChatColor.GRAY + "Cooldown: " + getConfig().getInt("doom-smash.cooldown-seconds", 18) + "s",
                ChatColor.DARK_RED + "Legendary Crate Reward"
        ));
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(doomKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (!isDoomMace(player.getInventory().getItemInMainHand())) return;
        event.setCancelled(true);

        long now = System.currentTimeMillis();
        long readyAt = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (readyAt > now) {
            long seconds = (readyAt - now + 999) / 1000;
            player.sendMessage(ChatColor.DARK_RED + "Doom Smash is recharging for " + ChatColor.RED + seconds + "s.");
            return;
        }

        int cooldown = Math.max(1, getConfig().getInt("doom-smash.cooldown-seconds", 18));
        cooldowns.put(player.getUniqueId(), now + cooldown * 1000L);
        // Short crimson charge-up before the impact.
        Location charge = player.getLocation().add(0, 0.9, 0);
        player.getWorld().playSound(charge, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8f, 0.65f);
        player.getWorld().spawnParticle(Particle.DUST, charge, 30, 0.45, 0.45, 0.45,
                new Particle.DustOptions(org.bukkit.Color.fromRGB(150, 0, 18), 1.7f));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) doomSmash(player);
        }, 3L);
    }

    private void doomSmash(Player player) {
        double radius = Math.max(1.0, getConfig().getDouble("doom-smash.radius", 5.0));
        double damage = Math.max(0.0, getConfig().getDouble("doom-smash.damage", 10.0));
        Location center = player.getLocation();
        World world = player.getWorld();

        world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.65f);
        world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.65f, 0.8f);
        world.spawnParticle(Particle.DUST, center.clone().add(0, 0.8, 0), 65, 0.8, 0.45, 0.8,
                new Particle.DustOptions(org.bukkit.Color.fromRGB(130, 0, 15), 2.0f));
        world.spawnParticle(Particle.SMOKE, center.clone().add(0, 0.5, 0), 28, 0.8, 0.3, 0.8, 0.04);

        for (Entity entity : world.getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof LivingEntity target) || entity.equals(player) || target.isDead()) continue;
            if (target instanceof Player victim && victim.getGameMode().name().equals("SPECTATOR")) continue;
            if (target.getLocation().distanceSquared(center) > radius * radius) continue;

            applyingAbilityDamage = true;
            try {
                target.damage(damage, player);
            } finally {
                applyingAbilityDamage = false;
            }
            Vector push = target.getLocation().toVector().subtract(center.toVector());
            if (push.lengthSquared() < 0.001) push = player.getLocation().getDirection().clone();
            push.normalize().multiply(getConfig().getDouble("doom-smash.knockback", 1.15));
            push.setY(Math.max(0.25, getConfig().getDouble("doom-smash.vertical-knockback", 0.35)));
            target.setVelocity(push);
            target.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SLOWNESS,
                    Math.max(1, getConfig().getInt("doom-smash.slowness-ticks", 30)),
                    Math.max(0, getConfig().getInt("doom-smash.slowness-amplifier", 0)), true, true, true));

            if (target.isDead() || (target instanceof LivingEntity living && living.getHealth() <= 0.0)) {
                playDoomExecution(target.getLocation());
            }
        }
    }

    @EventHandler
    public void onMeleeHit(EntityDamageByEntityEvent event) {
        if (applyingAbilityDamage) return;
        if (!(event.getDamager() instanceof Player player)) return;
        if (!isDoomMace(player.getInventory().getItemInMainHand())) return;

        event.setDamage(event.getDamage() * getConfig().getDouble("normal-attack.damage-multiplier", 1.25));
        double chance = getConfig().getDouble("normal-attack.wither-chance-percent", 8.0);
        if (event.getEntity() instanceof LivingEntity target && ThreadLocalRandom.current().nextDouble(100.0) < chance) {
            target.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.WITHER,
                    Math.max(1, getConfig().getInt("normal-attack.wither-duration-ticks", 40)),
                    Math.max(0, getConfig().getInt("normal-attack.wither-amplifier", 0)), true, true, true));
            target.getWorld().spawnParticle(Particle.DUST, target.getLocation().add(0, 1, 0), 18,
                    0.35, 0.5, 0.35, new Particle.DustOptions(org.bukkit.Color.fromRGB(145, 0, 20), 1.4f));
        }
    }

    private void playDoomExecution(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        Location base = location.clone().add(0, 0.1, 0);
        world.playSound(base, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 0.65f);
        world.playSound(base, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 0.9f);
        world.spawnParticle(Particle.DUST, base.clone().add(0, 1, 0), 55, 0.5, 0.8, 0.5,
                new Particle.DustOptions(org.bukkit.Color.fromRGB(190, 0, 25), 2.2f));
        world.spawnParticle(Particle.SOUL, base.clone().add(0, 1, 0), 16, 0.35, 0.6, 0.35, 0.03);

        // A jagged crimson particle bolt: cosmetic only, no extra damage.
        Vector[] offsets = {
                new Vector(0, 0, 0), new Vector(0.18, 0.75, 0.08),
                new Vector(-0.12, 1.5, -0.05), new Vector(0.15, 2.2, 0.1),
                new Vector(0.0, 3.0, 0.0)
        };
        for (int i = 0; i < offsets.length - 1; i++) {
            Vector from = offsets[i], to = offsets[i + 1];
            for (int step = 0; step <= 8; step++) {
                double t = step / 8.0;
                Location point = base.clone().add(from.clone().multiply(1.0 - t)).add(to.clone().multiply(t));
                world.spawnParticle(Particle.DUST, point, 2, 0.025, 0.025, 0.025,
                        new Particle.DustOptions(org.bukkit.Color.fromRGB(255, 15, 35), 1.8f));
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("doom")) return false;
        if (!sender.hasPermission("doommace.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }
        if (args.length != 2 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(ChatColor.RED + "Usage: /doom give <player>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "That player is not online.");
            return true;
        }
        Map<Integer, ItemStack> leftovers = target.getInventory().addItem(createDoomMace());
        leftovers.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        sender.sendMessage(ChatColor.GREEN + "Gave a Doom Mace to " + target.getName() + ".");
        target.sendMessage(ChatColor.DARK_RED + "You received the legendary Doom Mace!");
        return true;
    }
}
