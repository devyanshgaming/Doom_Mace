# DoomMace (Paper 1.21.5+ source project)

## Features
- Doom Mace is a vanilla `MACE` item with a persistent plugin marker, so renaming an ordinary mace cannot make it a Doom Mace.
- Right-click: Doom Smash, default 5-block radius, 10 raw damage points (5 hearts), knockback, 1.5 seconds of Slowness, 18-second per-player cooldown.
- Left-click melee: 1.25x damage multiplier and 8% Wither chance. It adds no custom attack cooldown; vanilla mace attack/smash timing still applies.
- Doom Smash kill: cosmetic jagged crimson particle lightning plus thunder/explosion sounds; no extra damage.
- No block damage; owner excluded from the ability's target list.
- `/doom give <player>` gives the weapon. Permission: `doommace.admin` (operators by default).
- Crate integration: configure your crate plugin to run `doom give %player%` as a console command, replacing `%player%` with that crate plugin's player placeholder.

## Install / build
This is a Maven source project. Build it with Java 21 and Maven 3.9+:

```sh
mvn clean package
```

The plugin JAR will be created at `target/doommace-1.0.0.jar`. Put that JAR into the server's `plugins` folder and restart.

## Compatibility note
Compiled against Paper API 1.21.5. It is intended for Paper 1.21.5 and newer, but future versions and forks should be tested before public release. Java 21 is required by the target Minecraft generation.

## Texture note
The item uses the vanilla mace model/texture. The dark-red accent is currently expressed through the custom name, lore and red ability particles. A true red pixel-art texture accent requires a matching server resource pack; it is not embedded in this plugin JAR.

## Configuration
Edit `plugins/DoomMace/config.yml` to tune ability radius, damage, cooldown, knockback, slowness and Wither chance. Restart the server after changes.

## Build without installing Java or Maven on your PC

This project includes a GitHub Actions workflow at `.github/workflows/build.yml`.
You can build it in GitHub's cloud environment:

1. Create a GitHub repository and upload the contents of this project (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build DoomMace** and click **Run workflow**.
4. When the run finishes, open it and download the **DoomMace-plugin** artifact.
5. Extract the artifact ZIP; it contains `doommace-1.0.0.jar`.

GitHub performs the Java/Maven build in the cloud; nothing needs to be installed locally.
